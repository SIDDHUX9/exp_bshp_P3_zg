# Battleship on 0G

On-chain Battleship on 0G Chain (EVM-compatible), with a heuristic AI opponent
for single-player mode.

## How it works

- Boards are hidden behind a Merkle-root commitment (one leaf per cell:
  `keccak256(x, y, isShip, salt)`). Nobody has to reveal their whole board —
  each shot is answered by revealing just that one cell plus a Merkle proof.
- Players strictly alternate turns: `fire(x, y)` → defender calls
  `revealCell(...)` → turn passes. First to land 17 hits (the standard fleet:
  5+4+3+3+2) wins.
- If the defender goes silent, the firer can call `claimTimeoutWin` after 10
  minutes.
- The AI opponent (`scripts/bot.js`) is a classic hunt/target heuristic
  bot — no LLM calls, runs entirely off-chain, fires moves through the same
  `fire`/`revealCell` calls a human player would use. See the "AI mode"
  section below for how a real single-player flow would wire it up.

## Project layout

```
contracts/BattleshipGame.sol   – the game contract
scripts/board.js                – fleet placement, Merkle tree, reveal/proof helpers
scripts/bot.js                  – heuristic hunt/target AI opponent
scripts/deploy.js               – deploy to 0G testnet/mainnet
test/BattleshipGame.test.js     – full game playthrough test (human vs bot)
```

## Setup

```bash
npm install
cp .env.example .env   # fill in PRIVATE_KEY for a 0G testnet wallet
npx hardhat compile
npx hardhat test
```

## Deploying to 0G

Testnet (chain ID 16602):
```bash
npx hardhat run scripts/deploy.js --network zgTestnet
```

Mainnet (chain ID 16661):
```bash
npx hardhat run scripts/deploy.js --network zgMainnet
```

You'll need testnet 0G tokens in the deployer wallet — check the 0G docs for
the current faucet.

## AI mode integration notes

For a real single-player UI, the bot doesn't need its own on-chain identity
logic beyond a wallet:

1. Generate a random board for the bot with `board.js`'s `generateBoard()`
   and commit its Merkle root when the game starts, same as a human player.
2. When it's the bot's turn, call `bot.nextMove()` to get `{x, y}`, submit
   `fire(gameId, x, y)` from the bot's wallet, then feed the result back with
   `bot.recordResult(x, y, isHit)` once the human reveals the cell.
3. When it's the human's turn to defend, your frontend reads the human's own
   stored board/salts (kept client-side) to answer `revealCell` — the bot
   never needs to see the human's board directly, only what the contract
   reveals.

This is all off-chain computation, so no gas cost beyond the normal
fire/reveal transactions. If you later want the "decentralized AI opponent"
pitch (routing bot moves through 0G Compute inference instead of a local
heuristic), swap out `bot.nextMove()` for an oracle/relayer call — the
contract interface doesn't change.
