// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {MerkleProof} from "@openzeppelin/contracts/utils/cryptography/MerkleProof.sol";

/// @title BattleshipGame
/// @notice Two-player on-chain Battleship. Boards are hidden behind a Merkle
///         commitment (leaf = keccak256(x, y, isShip, salt)); each shot is
///         answered by revealing just that one cell + its Merkle proof, so a
///         full board is never exposed until the game ends.
/// @dev MVP turn model: players strictly alternate turns (fire -> reveal ->
///      other player's turn), regardless of hit/miss. AI-mode games are just
///      normal games where one "player" is an EOA controlled by an off-chain
///      bot script that calls fire/commitBoard/revealCell like any user.
contract BattleshipGame {
    uint8 public constant TOTAL_SHIP_CELLS = 17; // standard fleet: 5+4+3+3+2
    uint256 public constant TURN_TIMEOUT = 10 minutes;

    enum Status {
        WaitingForPlayer,
        Placing,
        InProgress,
        Finished
    }

    enum ShotResult {
        Pending,
        Miss,
        Hit
    }

    struct Shot {
        uint8 x;
        uint8 y;
        ShotResult result;
        uint256 firedAt;
    }

    struct Game {
        address player1;
        address player2;
        Status status;
        bytes32 boardRoot1;
        bytes32 boardRoot2;
        uint8 hits1; // hits player1 has landed on player2's board
        uint8 hits2; // hits player2 has landed on player1's board
        address turn; // whose turn it is to fire
        address winner;
        Shot pendingShot; // shot awaiting reveal, fired at "turn"'s opponent
        bool hasPendingShot;
    }

    uint256 public nextGameId;
    mapping(uint256 => Game) public games;
    // gameId => player => (cellIndex => fired already, to prevent duplicate shots)
    mapping(uint256 => mapping(address => mapping(uint16 => bool))) public firedAt;

    event GameCreated(uint256 indexed gameId, address indexed player1);
    event GameJoined(uint256 indexed gameId, address indexed player2);
    event BoardCommitted(uint256 indexed gameId, address indexed player, bytes32 root);
    event ShotFired(uint256 indexed gameId, address indexed by, uint8 x, uint8 y);
    event ShotRevealed(uint256 indexed gameId, address indexed by, uint8 x, uint8 y, bool isHit);
    event GameFinished(uint256 indexed gameId, address indexed winner);
    event TimeoutClaimed(uint256 indexed gameId, address indexed winner);

    modifier onlyPlayers(uint256 gameId) {
        Game storage g = games[gameId];
        require(msg.sender == g.player1 || msg.sender == g.player2, "not a player");
        _;
    }

    function _opponent(Game storage g, address player) internal view returns (address) {
        return player == g.player1 ? g.player2 : g.player1;
    }

    function _boardRoot(Game storage g, address player) internal view returns (bytes32) {
        return player == g.player1 ? g.boardRoot1 : g.boardRoot2;
    }

    // ---------------------------------------------------------------
    // Setup
    // ---------------------------------------------------------------

    function createGame() external returns (uint256 gameId) {
        gameId = nextGameId++;
        Game storage g = games[gameId];
        g.player1 = msg.sender;
        g.status = Status.WaitingForPlayer;
        emit GameCreated(gameId, msg.sender);
    }

    function joinGame(uint256 gameId) external {
        Game storage g = games[gameId];
        require(g.status == Status.WaitingForPlayer, "not joinable");
        require(g.player1 != msg.sender, "cannot play yourself");
        g.player2 = msg.sender;
        g.status = Status.Placing;
        emit GameJoined(gameId, msg.sender);
    }

    /// @param merkleRoot root over 100 leaves: keccak256(abi.encodePacked(x, y, isShip, salt))
    function commitBoard(uint256 gameId, bytes32 merkleRoot) external onlyPlayers(gameId) {
        Game storage g = games[gameId];
        require(g.status == Status.Placing, "not in placing phase");
        require(merkleRoot != bytes32(0), "empty root");

        if (msg.sender == g.player1) {
            require(g.boardRoot1 == bytes32(0), "already committed");
            g.boardRoot1 = merkleRoot;
        } else {
            require(g.boardRoot2 == bytes32(0), "already committed");
            g.boardRoot2 = merkleRoot;
        }
        emit BoardCommitted(gameId, msg.sender, merkleRoot);

        if (g.boardRoot1 != bytes32(0) && g.boardRoot2 != bytes32(0)) {
            g.status = Status.InProgress;
            g.turn = g.player1; // player1 fires first
        }
    }

    // ---------------------------------------------------------------
    // Gameplay
    // ---------------------------------------------------------------

    function fire(uint256 gameId, uint8 x, uint8 y) external onlyPlayers(gameId) {
        Game storage g = games[gameId];
        require(g.status == Status.InProgress, "game not in progress");
        require(msg.sender == g.turn, "not your turn");
        require(!g.hasPendingShot, "awaiting reveal");
        require(x < 10 && y < 10, "out of bounds");

        uint16 cellIndex = uint16(y) * 10 + x;
        require(!firedAt[gameId][msg.sender][cellIndex], "already fired there");
        firedAt[gameId][msg.sender][cellIndex] = true;

        g.pendingShot = Shot({x: x, y: y, result: ShotResult.Pending, firedAt: block.timestamp});
        g.hasPendingShot = true;

        emit ShotFired(gameId, msg.sender, x, y);
    }

    /// @notice Called by the defender (opponent of whoever has g.turn) to reveal
    ///         whether the fired-at cell holds a ship, proven against their commitment.
    function revealCell(
        uint256 gameId,
        bool isShip,
        bytes32 salt,
        bytes32[] calldata proof
    ) external onlyPlayers(gameId) {
        Game storage g = games[gameId];
        require(g.status == Status.InProgress, "game not in progress");
        require(g.hasPendingShot, "no pending shot");
        address firer = g.turn;
        address defender = _opponent(g, firer);
        require(msg.sender == defender, "not the defender");

        Shot storage shot = g.pendingShot;
        bytes32 leaf = keccak256(abi.encodePacked(shot.x, shot.y, isShip, salt));
        require(MerkleProof.verify(proof, _boardRoot(g, defender), leaf), "invalid proof");

        shot.result = isShip ? ShotResult.Hit : ShotResult.Miss;
        g.hasPendingShot = false;

        if (isShip) {
            if (firer == g.player1) {
                g.hits1++;
            } else {
                g.hits2++;
            }
        }

        emit ShotRevealed(gameId, defender, shot.x, shot.y, isShip);

        uint8 firerHits = firer == g.player1 ? g.hits1 : g.hits2;
        if (firerHits >= TOTAL_SHIP_CELLS) {
            g.status = Status.Finished;
            g.winner = firer;
            emit GameFinished(gameId, firer);
            return;
        }

        // strict alternation for MVP simplicity
        g.turn = defender;
    }

    // ---------------------------------------------------------------
    // Timeouts / disputes
    // ---------------------------------------------------------------

    /// @notice If the defender never reveals within TURN_TIMEOUT, the firer can claim the win.
    function claimTimeoutWin(uint256 gameId) external onlyPlayers(gameId) {
        Game storage g = games[gameId];
        require(g.status == Status.InProgress, "game not in progress");
        require(g.hasPendingShot, "no pending shot");
        require(msg.sender == g.turn, "only the firer can claim");
        require(block.timestamp > g.pendingShot.firedAt + TURN_TIMEOUT, "timeout not reached");

        g.status = Status.Finished;
        g.winner = msg.sender;
        emit TimeoutClaimed(gameId, msg.sender);
        emit GameFinished(gameId, msg.sender);
    }

    // ---------------------------------------------------------------
    // Views
    // ---------------------------------------------------------------

    function getGame(uint256 gameId)
        external
        view
        returns (
            address player1,
            address player2,
            Status status,
            address turn,
            address winner,
            uint8 hits1,
            uint8 hits2
        )
    {
        Game storage g = games[gameId];
        return (g.player1, g.player2, g.status, g.turn, g.winner, g.hits1, g.hits2);
    }
}
