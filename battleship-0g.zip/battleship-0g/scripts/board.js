const { ethers } = require("hardhat");
const { MerkleTree } = require("merkletreejs");

const BOARD_SIZE = 10;
const FLEET = [5, 4, 3, 3, 2]; // standard Battleship fleet lengths

function cellIndex(x, y) {
  return y * BOARD_SIZE + x;
}

function leafHash(x, y, isShip, salt) {
  return ethers.solidityPackedKeccak256(
    ["uint8", "uint8", "bool", "bytes32"],
    [x, y, isShip, salt]
  );
}

/// Randomly place the standard fleet on a 10x10 grid, no overlaps, no wraparound.
function randomFleetPlacement() {
  const occupied = new Set();
  const ships = [];

  for (const length of FLEET) {
    let placed = false;
    while (!placed) {
      const horizontal = Math.random() < 0.5;
      const maxX = horizontal ? BOARD_SIZE - length : BOARD_SIZE - 1;
      const maxY = horizontal ? BOARD_SIZE - 1 : BOARD_SIZE - length;
      const x = Math.floor(Math.random() * (maxX + 1));
      const y = Math.floor(Math.random() * (maxY + 1));

      const cells = [];
      for (let i = 0; i < length; i++) {
        cells.push(horizontal ? [x + i, y] : [x, y + i]);
      }
      if (cells.some(([cx, cy]) => occupied.has(cellIndex(cx, cy)))) continue;

      cells.forEach(([cx, cy]) => occupied.add(cellIndex(cx, cy)));
      ships.push(cells);
      placed = true;
    }
  }
  return { ships, occupied };
}

/// Builds all 100 leaves (one per cell), a per-cell random salt, and the Merkle tree.
function buildBoard(occupied) {
  const leaves = [];
  const cells = []; // parallel array: {x, y, isShip, salt, leaf}

  for (let y = 0; y < BOARD_SIZE; y++) {
    for (let x = 0; x < BOARD_SIZE; x++) {
      const isShip = occupied.has(cellIndex(x, y));
      const salt = ethers.hexlify(ethers.randomBytes(32));
      const leaf = leafHash(x, y, isShip, salt);
      cells.push({ x, y, isShip, salt, leaf });
      leaves.push(leaf);
    }
  }

  const tree = new MerkleTree(leaves, ethers.keccak256, { sortPairs: true });
  const root = tree.getHexRoot();

  return { tree, root, cells };
}

/// Returns { isShip, salt, proof } for the cell at (x, y), ready to pass to revealCell().
function getReveal(board, x, y) {
  const cell = board.cells[cellIndex(x, y)];
  const proof = board.tree.getHexProof(cell.leaf);
  return { isShip: cell.isShip, salt: cell.salt, proof };
}

function generateBoard() {
  const { occupied } = randomFleetPlacement();
  return buildBoard(occupied);
}

module.exports = {
  BOARD_SIZE,
  FLEET,
  cellIndex,
  leafHash,
  randomFleetPlacement,
  buildBoard,
  generateBoard,
  getReveal,
};
