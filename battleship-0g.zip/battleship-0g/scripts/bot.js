const { BOARD_SIZE, FLEET } = require("./board");

const UNKNOWN = 0;
const MISS = 1;
const HIT = 2;

const DIRECTIONS = [
  [1, 0],
  [-1, 0],
  [0, 1],
  [0, -1],
];

/// Classic hunt/target Battleship AI:
///  - "hunt" mode fires on a checkerboard parity pattern (every ship is >=2
///    cells long, so this guarantees touching every possible ship placement
///    while roughly halving the number of blind shots vs a full scan).
///  - On a hit, switches to "target" mode: tries the four neighbors, and once
///    a second hit reveals the ship's orientation, keeps firing along that
///    line until it misses or the ship sinks.
class BattleshipBot {
  constructor() {
    this.grid = Array.from({ length: BOARD_SIZE }, () => Array(BOARD_SIZE).fill(UNKNOWN));
    this.mode = "hunt";
    this.targetQueue = []; // cells queued to try while in target mode
    this.firstHit = null; // {x,y} of the hit that started the current target run
    this.lastHit = null;
    this.direction = null; // [dx, dy] once orientation is known
    this.remainingLengths = [...FLEET]; // used to auto-detect a sunk ship from hit-run length
  }

  _inBounds(x, y) {
    return x >= 0 && x < BOARD_SIZE && y >= 0 && y < BOARD_SIZE;
  }

  _isUnfired(x, y) {
    return this._inBounds(x, y) && this.grid[y][x] === UNKNOWN;
  }

  _queueNeighbors(x, y) {
    for (const [dx, dy] of DIRECTIONS) {
      const nx = x + dx;
      const ny = y + dy;
      if (this._isUnfired(nx, ny) && !this.targetQueue.some((c) => c.x === nx && c.y === ny)) {
        this.targetQueue.push({ x: nx, y: ny });
      }
    }
  }

  /// Returns the next {x, y} to fire at.
  nextMove() {
    if (this.mode === "target" && this.targetQueue.length > 0) {
      // If we know the orientation, prefer the cell that continues the line.
      if (this.direction && this.lastHit) {
        const [dx, dy] = this.direction;
        const nx = this.lastHit.x + dx;
        const ny = this.lastHit.y + dy;
        if (this._isUnfired(nx, ny)) return { x: nx, y: ny };
      }
      return this.targetQueue.shift();
    }

    // Hunt mode: checkerboard parity scan over unfired cells.
    const candidates = [];
    for (let y = 0; y < BOARD_SIZE; y++) {
      for (let x = 0; x < BOARD_SIZE; x++) {
        if ((x + y) % 2 === 0 && this.grid[y][x] === UNKNOWN) {
          candidates.push({ x, y });
        }
      }
    }
    const pool = candidates.length > 0 ? candidates : this._allUnfired();
    return pool[Math.floor(Math.random() * pool.length)];
  }

  _allUnfired() {
    const cells = [];
    for (let y = 0; y < BOARD_SIZE; y++) {
      for (let x = 0; x < BOARD_SIZE; x++) {
        if (this.grid[y][x] === UNKNOWN) cells.push({ x, y });
      }
    }
    return cells;
  }

  /// Feed back the result of a shot so the bot can update its strategy.
  recordResult(x, y, isHit) {
    this.grid[y][x] = isHit ? HIT : MISS;
    // drop this cell from the queue if it was pending
    this.targetQueue = this.targetQueue.filter((c) => !(c.x === x && c.y === y));

    if (!isHit) {
      // If we were pursuing a line and just missed, try the opposite direction
      // from the original hit before giving up on this ship.
      if (this.mode === "target" && this.direction && this.firstHit) {
        const [dx, dy] = this.direction;
        this.direction = [-dx, -dy];
        this.lastHit = this.firstHit;
        const nx = this.firstHit.x + this.direction[0];
        const ny = this.firstHit.y + this.direction[1];
        if (!this._isUnfired(nx, ny)) this._giveUpTarget();
      } else if (this.mode === "target" && this.targetQueue.length === 0) {
        this._giveUpTarget();
      }
      return;
    }

    // Hit.
    if (this.mode === "hunt") {
      this.mode = "target";
      this.firstHit = { x, y };
      this.lastHit = { x, y };
      this._queueNeighbors(x, y);
    } else {
      // Second+ hit while targeting: lock in orientation if not known yet.
      if (!this.direction && this.firstHit) {
        this.direction = [x - this.firstHit.x, y - this.firstHit.y];
        this.targetQueue = []; // stop guessing neighbors, follow the line instead
      }
      this.lastHit = { x, y };
    }

    if (this.direction) this._checkSunk();
  }

  _scanRun(x, y, dx, dy) {
    let count = 0;
    let cx = x;
    let cy = y;
    while (this._inBounds(cx, cy) && this.grid[cy][cx] === HIT) {
      count++;
      cx += dx;
      cy += dy;
    }
    return count;
  }

  /// Heuristic: once we know a hit-line's orientation, a run of consecutive
  /// hits bounded on both ends by a miss or the board edge, whose length
  /// matches one of the remaining (undestroyed) ship lengths, is treated as
  /// sunk. This assumes ships aren't placed touching each other end-to-end
  /// with the same length — true for the classic placement rules, but note
  /// it's an approximation since the contract itself doesn't expose per-ship
  /// boundaries, only aggregate hit count.
  _checkSunk() {
    const [dx, dy] = this.direction;
    const forward = this._scanRun(this.firstHit.x, this.firstHit.y, dx, dy);
    const backward = this._scanRun(this.firstHit.x, this.firstHit.y, -dx, -dy);
    const runLength = forward + backward - 1;

    const idx = this.remainingLengths.indexOf(runLength);
    if (idx === -1) return;

    this.remainingLengths.splice(idx, 1);
    this._giveUpTarget();
  }

  /// Call manually if you have ground truth (e.g. in tests) that a ship sank.
  shipSunk() {
    this._giveUpTarget();
  }

  _giveUpTarget() {
    this.mode = "hunt";
    this.targetQueue = [];
    this.firstHit = null;
    this.lastHit = null;
    this.direction = null;
  }
}

module.exports = { BattleshipBot };
