const { ethers, network } = require("hardhat");

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying with:", deployer.address, "on", network.name);

  const Game = await ethers.getContractFactory("BattleshipGame");
  const game = await Game.deploy();
  await game.waitForDeployment();

  const address = await game.getAddress();
  console.log("BattleshipGame deployed to:", address);
  console.log(
    network.name === "zgTestnet"
      ? `Explorer: https://chainscan-galileo.0g.ai/open/address/${address}`
      : "Deployed."
  );
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
