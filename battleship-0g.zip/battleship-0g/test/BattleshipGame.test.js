const { expect } = require("chai");
const { ethers } = require("hardhat");
const { generateBoard, getReveal, BOARD_SIZE } = require("../scripts/board");
const { BattleshipBot } = require("../scripts/bot");

describe("BattleshipGame", function () {
  it("plays a full human-vs-bot game to completion", async function () {
    const [human, bot] = await ethers.getSigners();

    const Game = await ethers.getContractFactory("BattleshipGame");
    const game = await Game.deploy();
    await game.waitForDeployment();

    // --- setup ---
    await (await game.connect(human).createGame()).wait();
    const gameId = 0n;
    await (await game.connect(bot).joinGame(gameId)).wait();

    const humanBoard = generateBoard();
    const botBoard = generateBoard();
    await (await game.connect(human).commitBoard(gameId, humanBoard.root)).wait();
    await (await game.connect(bot).commitBoard(gameId, botBoard.root)).wait();

    const [, , status] = await game.getGame(gameId);
    expect(status).to.equal(2n); // InProgress

    const ai = new BattleshipBot();

    // A trivial "always fire center-out" stand-in for the human player, so the
    // test doesn't need real UI input — swap this for actual player input.
    let humanMoveIdx = 0;
    const humanMoves = [];
    for (let y = 0; y < BOARD_SIZE; y++) {
      for (let x = 0; x < BOARD_SIZE; x++) humanMoves.push({ x, y });
    }

    let finished = false;
    let winner;
    for (let turn = 0; turn < 300 && !finished; turn++) {
      const [, , , currentTurn] = await game.getGame(gameId);

      if (currentTurn.toLowerCase() === human.address.toLowerCase()) {
        const { x, y } = humanMoves[humanMoveIdx++];
        await (await game.connect(human).fire(gameId, x, y)).wait();
        const reveal = getReveal(botBoard, x, y);
        await (
          await game.connect(bot).revealCell(gameId, reveal.isShip, reveal.salt, reveal.proof)
        ).wait();
      } else {
        const { x, y } = ai.nextMove();
        await (await game.connect(bot).fire(gameId, x, y)).wait();
        const reveal = getReveal(humanBoard, x, y);
        await (
          await game.connect(human).revealCell(gameId, reveal.isShip, reveal.salt, reveal.proof)
        ).wait();
        ai.recordResult(x, y, reveal.isShip);
      }

      const [, , newStatus, , newWinner] = await game.getGame(gameId);
      if (newStatus === 3n) {
        finished = true;
        winner = newWinner;
      }
    }

    expect(finished, "game should finish within move budget").to.equal(true);
    expect([human.address, bot.address]).to.include(winner);
  });
});
